import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.net.*;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ServerProxy {
    public static void main(String[] args) throws Exception {
        int port = 8888;
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
        server.createContext("/", new RootHandler());
        System.out.println("Starting server on port: " + port);
        server.start();
    }

    static class RootHandler implements HttpHandler {
        public void handle(HttpExchange exchange) throws IOException {
//            Pobranie metody
            String requestMethod = exchange.getRequestMethod();

//            Ustawienie adresu
            URL addres = exchange.getRequestURI().toURL();
//            System.out.println(addres);
            System.out.println("Address: " + addres);

//            Connection setup
            HttpURLConnection conn = (HttpURLConnection) addres.openConnection();

//            Przepisanie RequestHeaders do connection
            Headers headers = exchange.getRequestHeaders();
            Set<Map.Entry<String, List<String>>> entrySet = headers.entrySet();
            for (Map.Entry<String, List<String>> entry : entrySet) {
                String headerKeyName = entry.getKey();
//                System.out.println(headerKeyName);
                List<String> headerValues = entry.getValue();
                for (String value : headerValues) {
//                    System.out.println(headerKeyName + ": " + value);
                    if (headerKeyName != null)
                        conn.setRequestProperty(headerKeyName, value);
                }
            }
//            for (String key : headers.keySet()) {
//                conn.setRequestProperty(key, headers.get(key).get(0));
//            }

            conn.setInstanceFollowRedirects(false);
            conn.setRequestMethod(exchange.getRequestMethod());
            conn.connect();

//            Przepisanie ConnectionHeaders do exchange ResponseHeaders
            Map headerFields = conn.getHeaderFields();
            for (Iterator iterator = headerFields.keySet().iterator(); iterator.hasNext();) {
                String key = (String) iterator.next();
//                System.out.println(key + " = ");
                List values = (List) headerFields.get(key);
                for (int i = 0; i < values.size(); i++) {
                    Object v = values.get(i);
//                    System.out.println(key + ": " + v);
                    if (key != null)
                        exchange.getResponseHeaders().set(key, v.toString());
                }
            }
            exchange.getResponseHeaders().set("Via", "localhost:8888");
            exchange.getResponseHeaders().set("Client-Ip", exchange.getRemoteAddress().toString());

            InputStream stream;
            try {
                stream = conn.getInputStream();
            } catch (Exception e) {
                stream = conn.getErrorStream();
                System.out.println(e.getStackTrace());
            }

            byte[] streamBytes = streamToBytes(stream);
            exchange.sendResponseHeaders(conn.getResponseCode(), streamBytes.length);
            OutputStream os = exchange.getResponseBody();
            os.write(streamBytes);
            os.close();
        }

        public static byte[] streamToBytes(InputStream input) throws IOException
        {
            byte[] buffer = new byte[8192];
            int bytesRead;
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            while ((bytesRead = input.read(buffer)) != -1)
            {
                output.write(buffer, 0, bytesRead);
            }
            return output.toByteArray();
        }
    }
}